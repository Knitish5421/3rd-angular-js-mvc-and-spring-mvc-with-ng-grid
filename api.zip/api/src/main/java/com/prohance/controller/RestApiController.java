package com.prohance.controller;

import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.prohance.exception.RecordNotFoundException;
import com.prohance.mapper.dao.EmployeeMapper;
import com.prohance.model.Check;
import com.prohance.model.Employee;
import com.prohance.model.Login;

@Controller
public class RestApiController {
	@Autowired
	EmployeeMapper employeeMapper;
	Check ln=new Check();
	
	@RequestMapping(value = "/login", produces = "application/json", method = RequestMethod.POST)
	public ResponseEntity<Check> login(@RequestBody Login login, HttpServletRequest req)
			throws RecordNotFoundException { 
 System.out.println(login.getUsername());
        Check ln=new Check();
		String username = "Nitish";
		String  password = "kumar";
		if(login.getUsername().equalsIgnoreCase(username)&&login.getPassword().equalsIgnoreCase(password)) {
			ln.setCondition("suceess");
			return new ResponseEntity<Check>(ln, HttpStatus.OK);
		}
		ln.setCondition("fail");
		return new ResponseEntity<Check>(ln, HttpStatus.OK);
	}
	

	@RequestMapping(value = "/employees", produces = "application/json")
	public ResponseEntity<List<Employee>> getAllEmployees() {
		List<Employee> list = employeeMapper.getAllEmployees();
		return new ResponseEntity<List<Employee>>(list, new HttpHeaders(), HttpStatus.OK);
	}

	@RequestMapping(value = "/employees/{id}", produces = "application/json")
	public ResponseEntity<?> getEmployeeById(@PathVariable("id") Long id) throws RecordNotFoundException {
		System.out.println(id);
		Employee entity = employeeMapper.getDataById(id);
		if (entity == null) {
			return new ResponseEntity<String>("No Customer found for ID " + id, HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Employee>(entity, new HttpHeaders(), HttpStatus.OK);
	}

	@RequestMapping(value = "/employee", produces = "application/json", method = RequestMethod.POST)
	public ResponseEntity<?> insertEmployee(@RequestBody Employee employee, HttpServletRequest req)
			throws RecordNotFoundException { 

		String fname = employee.getFirstname();
		String lname = employee.getLastname();
		boolean flag = true;
		List<Employee> employeeList = employeeMapper.getFnameLname(fname);
		Iterator<Employee> itr = employeeList.iterator();
		while (itr.hasNext()) {
			Employee emps = itr.next();
			System.out.println(emps.getFirstname().trim().equals(fname) && emps.getLastname().trim().equals(lname));
			if (emps.getFirstname().trim().equals(fname) && emps.getLastname().trim().equals(lname)) {
				flag = false;
			}
		}
		if (flag) {
			Integer emp = employeeMapper.insert(employee);
			return new ResponseEntity<String>("{}", HttpStatus.OK);
		}
		return new ResponseEntity<String>("n", HttpStatus.OK);
	}

	
	@RequestMapping(value = "/update", produces = "application/json", method = RequestMethod.POST)
	public ResponseEntity<?> updateEmployee(@RequestBody Employee employee, HttpServletRequest req)
			throws RecordNotFoundException {
			if (employeeMapper.getDataById(employee.getId()).getFirstname()!=null)
			{
				employeeMapper.updateById(employee);
				return new ResponseEntity<String>("{}", HttpStatus.OK);
			}
			
		
		return new ResponseEntity<String>("Record Not Found ", HttpStatus.OK);
	}
	@RequestMapping(value = "/employee/{id}", produces = "application/json", method = RequestMethod.DELETE)
	public ResponseEntity<?> deleteByCustId(@PathVariable("id") Long id) throws RecordNotFoundException {
		System.out.println("fsdffs");
		Integer is = employeeMapper.deletById1(id);
		if (is == null) {
			return new ResponseEntity<String>(id + "sucessfully  not deleted" + id, HttpStatus.NOT_FOUND);
		}
		employeeMapper.deletById(id);
		return new ResponseEntity<String>(id + "sucessfully deleted" + new HttpHeaders(), HttpStatus.OK);

	}


	
	
	
	/*
	@RequestMapping(value = "/employee", produces = "application/json", method = RequestMethod.POST)
	public ResponseEntity<?> insertEmployee(@RequestBody Employee employee, HttpServletRequest req)
			throws RecordNotFoundException { 
		String fname = employee.getFirstname();
		String lname = employee.getLastname();

		boolean flag = true;
		List<Employee> employeeList = employeeMapper.getFnameLname(fname);
		Iterator<Employee> itr = employeeList.iterator();
		while (itr.hasNext()) {
			Employee emps = itr.next();
			if (emps.getFirstname().trim().equals(fname) && emps.getLastname().trim().equals(lname)) {
				flag = false;
			}
		}

		if (flag) {
			if (!employee.getFirstname().equals("") && !employee.getLastname().equals("")
					&& (employee.getGender().equalsIgnoreCase("M") || employee.getGender().equalsIgnoreCase("F"))
					&& employee.getAge() > 0 && employee.getAge() <= 100 &&

					((employee.getState().equalsIgnoreCase("bihar") && (employee.getCity().equalsIgnoreCase("patna")
							|| employee.getCity().equalsIgnoreCase("gaya")))
							|| (employee.getState().equalsIgnoreCase("karnataka")
									&& (employee.getCity().equalsIgnoreCase("bangalore")
											|| employee.getCity().equalsIgnoreCase("mysuru")))
							|| (employee.getState().equalsIgnoreCase("jharkhand")
									&& (employee.getCity().equalsIgnoreCase("ranchi")
											|| employee.getCity().equalsIgnoreCase("dhanbaad"))))
					&&

					(employee.getSkills().equalsIgnoreCase("java") || employee.getSkills().equalsIgnoreCase("js")
							|| employee.getSkills().equalsIgnoreCase("j2ee")
							|| employee.getSkills().equalsIgnoreCase("spring"))
					&& !employee.getAddress().equals(""))

			{
				System.out.println("vxjv22222");
				Integer emp = employeeMapper.insert(employee);

				return new ResponseEntity<String>("{}", HttpStatus.OK);

			}
		}
		//Integer update = employeeMapper.updateById(employee);
		System.out.println("nitish");
		return new ResponseEntity<String>("n", HttpStatus.OK);

	}

	 */
	

	@RequestMapping(value = "/dataById/{id}", produces = "application/json", method = RequestMethod.POST)
	public ResponseEntity<Employee> updateEmployee(@PathVariable("id") Long id) throws RecordNotFoundException {

		 Employee dataByid=employeeMapper.getDataById(id);
		return new ResponseEntity<Employee>(dataByid, HttpStatus.OK);
	}

	

}
