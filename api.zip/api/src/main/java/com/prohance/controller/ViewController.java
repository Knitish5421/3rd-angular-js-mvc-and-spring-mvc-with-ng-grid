package com.prohance.controller;

import java.io.IOException;



import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.view.RedirectView;

import com.prohance.mapper.dao.EmployeeMapper;
import com.prohance.model.Employee;
import com.prohance.service.Service;

public class ViewController {
	/*
    @RequestMapping("/")
	public String index()
	{
		return"index";
	}
	*/
	    
}

 
