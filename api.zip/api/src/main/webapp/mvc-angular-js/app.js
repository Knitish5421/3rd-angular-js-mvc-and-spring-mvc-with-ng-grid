
var app = angular.module("loginApp", ['ui.router','ngGrid']);
app.config(function($stateProvider, $urlRouterProvider) {
	
$urlRouterProvider.otherwise('/login');	

$stateProvider

.state('login', { 
    url : '/login', 
    templateUrl : "template/login.html", 
    controller : "loginController"
}) 
.state('views', {
    url: '/views',
    templateUrl: 'template/view.html',
    controller: 'NgGridController'
})
 
})


